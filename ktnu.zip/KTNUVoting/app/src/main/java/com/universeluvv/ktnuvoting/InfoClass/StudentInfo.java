package com.universeluvv.ktnuvoting.InfoClass;

public class StudentInfo {

   private String name, major, id, coin, walletaddress, authority;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCoin() {
        return coin;
    }

    public void setCoin(String coin) {
        this.coin = coin;
    }

    public String getWalletaddress() {
        return walletaddress;
    }

    public void setWalletaddress(String walletaddress) {
        this.walletaddress = walletaddress;
    }

    public String getAuthority() {
        return authority;
    }

    public void setAuthority(String authority) {
        this.authority = authority;
    }
}
